# Backlog

Short entries only — a sentence or two each. See `prompts/09-iterate.md` for how items get promoted into Work Cards.

Format per item: `- [size guess] Description (how it was noticed)`

## Open

### [small] — likely one Work Card each, no architecture pass

_(empty as of 2026-10-02 — all five promoted as Cards 22–26, see Promoted)_

### [medium] — additive to schema/logic; short spec line before the card, no architecture pass

- [medium] Trend-aware early warning using existing `readings` history — the window and slope threshold that count as "climbing fast" are defined **in the card**, not while building (builder QoL brainstorm, post-ship)
- [medium] Snooze/mute notifications for a set period — needs a `muted_until`-style `devices` field; card defines the allowed durations and where the control lives (builder QoL brainstorm, post-ship)

### [needs architecture.md first] — no Work Cards without builder sign-off on the architecture update

- [needs architecture] Forecast data (WAQI's existing 3–8 day forecast) — changes what gets cached: forecast has a different shape and lifecycle than a point-in-time `readings` row, so the storage model needs an architecture decision first (builder QoL brainstorm, post-ship)
- [needs architecture] Comparison mode (2–3 locations side by side) — an extension of the Map & Station Explorer architecture; note: that conversation is **no longer pending** — it was confirmed 2026-09-15 and shipped as Cards 11–12, so this is a **new addendum to the confirmed "Map & Station Explorer" section**, not to an undecided one (builder QoL brainstorm, post-ship)
- [needs architecture] Crowd-sourced "smell test" map layer — needs a new `reports` table plus real abuse/rate-limit handling before it is buildable at all; also a moderation/quality question, not just storage (builder QoL brainstorm, post-ship)

### [blocked on something else]

- [blocked] Shareable saved-location links — depends on saved locations/watchlist existing first, which is itself still just a Later-list idea in `project-brief.md` (builder QoL brainstorm, post-ship)

### Bigger, cross-cutting

- [multi-card sequence] Bilingual BM/EN toggle — **not one card**: copy lives on nearly every screen (reading card, threshold, prompts, install instructions, map screen, states). Needs its own scope pass (string-extraction approach, which strings move to a dictionary, design.md line-length implications) and a sequence of cards per screen group, so it doesn't get squeezed into one card and done badly (builder QoL brainstorm, post-ship)
- [medium, needs design.md pass first] Auto-generated shareable haze report images — canvas-generated share card; doesn't touch the data model, but the card's visual design needs a `design.md` pass (styling of the generated image) before implementation, per the design-first rule (builder QoL brainstorm, post-ship)

- [L] Post-v1: migrate the backend from Bun + Express + SQLite to Supabase (Postgres + Edge Functions + `pg_cron`) — storage, routes, the poll job, Web Push dispatch, and the server tests all need rework; revisit `architecture.md` as a structural change before any code (noticed during Card 08 host planning — builder chose Supabase but deferred it to ship v1 on the current stack first)

## Promoted

- [small] → `work-cards/22-app-icon-badge.md` — Badging API AQI badge (`setAppBadge(aqi)`, clear on unreadable/offline, no-op where unsupported) (promoted 2026-10-02 — builder backlog pick "1–4", stream 1; build order 22 → 26)
- [small] → `work-cards/23-web-share-reading.md` — Web Share "Share this reading" control, hidden where `navigator.share` is missing (promoted 2026-10-02 — builder backlog pick "1–4", stream 1)
- [small] → `work-cards/24-threshold-share-url.md` — `?threshold=NN` read on load, pre-fills (never auto-saves) the setter, param stripped after consume; threshold only (promoted 2026-10-02 — builder backlog pick "1–4", stream 1)
- [small] → `work-cards/25-status-page.md` — public `/status` + `/status.json` (server up, last poll time/outcome from a new `meta` row written by the poll job, WAQI state from the last poll — no live probing) (promoted 2026-10-02 — builder backlog pick "1–4", stream 1; includes the code-checked poll-time field)
- [small] → `work-cards/26-good-day-microcopy.md` — one calm Good-only line ("Clear enough to open the windows today."), fresh readings only (promoted 2026-10-02 — builder backlog pick "1–4", stream 1)
- [medium] → `work-cards/27-dominant-pollutant.md` — parser reads `dominentpol`, `readings.dominant_pollutant` column (guarded migration), route passthrough, muted UI line; spec line lives in the card (promoted 2026-10-02 — builder backlog pick "1–4", stream 2)

- [medium] → `work-cards/21-worldwide-station-coverage.md` — worldwide suggestions (`/api/search` no longer MY-only, cap 20, drop coordinate-less rows), cap-subdivided map-view collection shared with the world-overview crawl, and the ≤30°/side viewport reject replaced by clamped/wrapped ≤30° cell planning so wide zoom-4–6 viewports return every station instead of 400-ing (promoted 2026-09-27 — direct builder directive, not a queued backlog pick)

- [medium] → `work-cards/13-quiet-hours.md` — quiet hours for notifications (per-device UTC window in the `devices` schema) with the 300+ hazardous override explicitly bypassing quiet hours (promoted 2026-09-15 — builder priority 1 of 3: quiet hours → city-change detection → DOE guidance line)

- [medium] → `work-cards/14-city-change-detection.md` — surface a calm "location updated" hint when a fresh GPS fix resolves to a different station than last time; the card defines the significant-move threshold as **station identity** (not raw GPS distance — station flips are the app's resolution unit, ~10–15 km+ in the 65-station network), plus a small `devices.last_station_name` record (promoted 2026-09-15 — builder priority 2 of 3)

- [medium] → `work-cards/15-doe-guidance-line.md` — DOE guidance line under the reading, **unblocked by the builder's option-1 sourcing decision** (2026-09-15): ships citing the National Haze Action Plan — outdoor activities suspended above API 100, schools close above API 200 (the API 150/NADMA trigger stays in the card's sourcing note, not the UI) — with the mandatory Malaysian-API-vs-US-AQI scale caveat; agent-side fetches were bot-blocked, verification chain builder-attested (RTM quoting DOE Deputy DG + corroborating outlets) and logged in the card (promoted 2026-09-15 — builder priority 3 of 3)

- [S] → `work-cards/10-city-fallback-station-coordinates.md` — the city-station fallback path in `GET /api/reading` returns `lat: 0, lng: 0` instead of the station's real coordinates, so a device's recorded location (via the frontend's `POST /api/devices` at Card 08) becomes `0,0 — the poll job then resolves future readings against `nearestCityStation(0,0)` rather than the user's actual Malaysian location (noticed during Card 08 live deploy verification — non-blocking for v1 proof, poll still fires, but the wrong station may be used)

- [S] → `work-cards/09-severity-scale-split.md` — split the app's severity system into the official 6-band US EPA/WAQI scale (`app/src/theme/severity.ts` and `app/src/styles.css` still merge USG/Unhealthy/Very Unhealthy into one "Unhealthy" band up to 300), giving each band a `--sev-*` pair per `design.md`; also point the AQI number at the band's dark text color instead of the bright accent (`--sev-moderate` is currently `#F9A825`, ~1.85:1 on the app background) (noticed during the `design.md` revision — see Decisions made in `build-status.md`)
